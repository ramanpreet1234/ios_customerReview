//
//  TablecellTableViewCell.swift
//  CustomerReview
//
//  Created by MacStudent on 2018-08-11.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
class TablecellTableViewCell: UITableViewCell {
    @IBOutlet weak var imgtable: UIImageView!
    @IBOutlet weak var btnAction: UIButton!
    
    @IBOutlet weak var lbltitle: UILabel!
    @IBOutlet weak var lbldes: UILabel!
   
    @IBAction func btnAction(_ sender: UIButton) {
        print("Hello ")
    }
    }
