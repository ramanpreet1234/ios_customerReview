//
//  Review.swift
//  CustomerReview
//
//  Created by MacStudent on 2018-08-15.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class Review: UIViewController,UIPickerViewDataSource,UIPickerViewDelegate {

    @IBOutlet weak var ratingStackView: UIStackView!
    @IBOutlet weak var txtComments: UITextField!
    @IBOutlet weak var pickCategory: UIPickerView!
    @IBOutlet weak var txtPlaceName: UITextField!
//    @IBAction func btnSubmit(_ sender: Any) {
//    }
    
    let categoryList : [String] = ["Restaurants", "Hotels", "Tourist Attraction"]
    
    override func viewWillAppear(_ animated: Bool) {
        self.title = "Review"
        navigationController?.setNavigationBarHidden(false, animated: true)
    
        let btnSubmit = UIBarButtonItem(title: "Submit", style: .plain, target: self, action: #selector(displayInfo))
        self.navigationItem.rightBarButtonItem = btnSubmit
    }
    
    @objc func displayInfo(){
            var userInfo : String = txtComments.text!
            userInfo += "\n" + txtPlaceName.text!
            userInfo += "\n \(categoryList[pickCategory.selectedRow(inComponent: 0)])"

        
        let infoAlert = UIAlertController(title: "Verify Details", message: userInfo, preferredStyle: .alert)
        
      
        
        infoAlert.addAction(UIAlertAction(title: "Confirm", style: .cancel, handler:{_ in self.displayHomeVC()        }))
        self.present(infoAlert,animated: true, completion: nil)
        let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let resVC = mainSB.instantiateViewController(withIdentifier: "ResScene")
        
        
        }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return  1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return categoryList.count
    }
    
    
    func pickerView(_pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return categoryList[row]
    }
    override func viewDidLoad() {
            super.viewDidLoad()
            
            pickCategory.delegate = self
            pickCategory.dataSource = self
            
            
        // Do any additional setup after loading the view.
        
    }

//        func btnClicked(_ sender: UIButton) {
//
//
//        }
        
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
        func displayHomeVC()
        {
            let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let signUpVC = mainSB.instantiateViewController(withIdentifier: "TableScene")
              navigationController?.pushViewController(signUpVC, animated: true)}

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

