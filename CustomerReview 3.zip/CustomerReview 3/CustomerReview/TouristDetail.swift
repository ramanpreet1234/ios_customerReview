//
//  TouristDetail.swift
//  CustomerReview
//
//  Created by MacStudent on 2018-08-17.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class TouristDetail: UIViewController {
    @IBOutlet weak var imgTourist: UIImageView!
    @IBOutlet weak var lblname: UILabel!
    @IBOutlet weak var lbldesp: UILabel!
    
    var plistArray = NSMutableArray()
    var selectedtourist: Int?
    
    override func viewWillAppear(_ animated: Bool) {
        if let index = selectedtourist  {
            self.fetchDetails()
            self.displayDetails()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func displayDetails(){
       // lblname.text = Tourist.TName[self.selectedtourist!]
        let touristDetails = plistArray[self.selectedtourist!] as! NSMutableArray
          lblname.text = Tourist.TName[self.selectedtourist!] as? String
        self.lbldesp.text = touristDetails.value(forKey: "TDes") as? String
        self.imgTourist.image = touristDetails.value(forKey: "Timage") as! UIImage
    }
    func fetchDetails(){
        if let filePath = Bundle.main.path(forResource: "TouristList", ofType: "plist"){
            //get an array representation of plist
            plistArray = NSMutableArray(contentsOfFile: filePath)!
            
            print("plistArray \(plistArray)")
        }
    }
    
    
    
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
