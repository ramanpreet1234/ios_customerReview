//
//  LaunchViewController.swift
//  CustomerReview
//
//  Created by MacStudent on 2018-08-18.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class LaunchViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }


override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    moveToNextController()
}

func moveToNextController(){
    sleep(1)
    self.navigationController?.pushViewController(UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginScene"), animated: true)
    //Push
}

    //    func delay(_ delay:Double, closure:@escaping ()->()) {
    //        let when = DispatchTime.now() + delay
    //        DispatchQueue.main.asyncAfter(deadline: when, execute: closure)
    //    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
