//
//  TouristCell.swift
//  CustomerReview
//
//  Created by MacStudent on 2018-08-17.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class TouristCell: UITableViewCell {

    @IBOutlet weak var lblname: UILabel!
    @IBOutlet weak var imgtourist: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
